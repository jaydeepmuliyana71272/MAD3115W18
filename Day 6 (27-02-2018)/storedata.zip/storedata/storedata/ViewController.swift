//
//  ViewController.swift
//  storedata
//
//  Created by MacStudent on 2018-02-27.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtCarPlate: UITextField!
    @IBOutlet weak var txtCarColor: UITextField!
   
    @IBAction func btnAdd(_ sender: UIButton)
    {
        self.writePropertyList()
    }
    @IBAction func btnList(_ sender: UIButton)
    {
        
    }
    
    func writePropertyList()
    {
        let myCar = NSMutableDictionary()
        myCar["CarPlate"] = self.txtCarPlate.text
        myCar["CarColor"] = self.txtCarColor.text
        
       if let plistPath = Bundle.main.path(forResource: "car", ofType: "plist")
        {
            let carsplist = NSMutableArray(contentsOfFile: plistPath)
            carsplist?.add(myCar)
            if (carsplist?.write(toFile: plistPath, atomically: true))!
            {
                print("car list : \(String (describing: carsplist))")
            }
        }
        else
       {
            print("Unable to locate file!!!!! ")
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

