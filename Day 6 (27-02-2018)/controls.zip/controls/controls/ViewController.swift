//
//  ViewController.swift
//  controls
//
//  Created by MacStudent on 2018-02-27.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lblSlider: UILabel!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
   
    @IBOutlet weak var selectSegment: UISegmentedControl!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var selectStepper: UIStepper!
    @IBOutlet weak var slide: UISlider!
    @IBOutlet weak var progressBar: UIProgressView!
    
   
    @IBOutlet weak var percent: UILabel!
    @IBOutlet weak var lblSteeperValue: UILabel!
    var images: [UIImage] = [UIImage(named: "dog1.jpeg")!,UIImage(named: "dog2.jpeg")!, UIImage(named: "dog3.jpeg")!]
    
    var progressTimer = Timer()
    
    @IBAction func btnProgress(_ sender: UIButton)
    {
        self.progressBar.progress += 0.01
        self.percent.text = "\(Int(self.progressBar.progress * 100))%"
        
        if self.progressBar.progress >= 1
        {
            self.progressTimer.invalidate()
        }
    }
    
    @IBAction func SliderAction(_ sender: UISlider)
    {
        lblSlider.text = String(slide.value)
    }
    @IBAction func StepperAction(_ sender: UIStepper)
    {
        lblSteeperValue.text = String(selectStepper.value)
    }
    
    @IBAction func segmentChange(_ sender: UISegmentedControl)
    {
        print("selected : \(selectSegment.selectedSegmentIndex)")
        
        img.image = images[selectSegment.selectedSegmentIndex] 
        
    }
    
    @IBAction func btnStart(_ sender: UIButton)
    {
       activityIndicator.startAnimating()
    }
    
    @IBAction func btnStop(_ sender: UIButton)
    {
        activityIndicator.stopAnimating() 
    }
 
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        progressBar.progress = 0.0
        percent.text = "\(Int(progressBar.progress*100))%"
        self.progressTimer = Timer.scheduledTimer(timeInterval: 0.2, target: self, selector: #selector(self.btnProgress), userInfo: nil, repeats: true) 
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

